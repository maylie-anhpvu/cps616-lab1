
/*
    Fill in this block comment before submitting.
    Name: <your name here>
*/

#include <iostream>
#include <stdlib.h>

// You are not limited to these functions. 
// Write as many helpers as you want
// You might find it useful to overload and
// pass additional arguments, for example.

void selection_sort(int *arr, int n)
{
	// Your code here
}

void merge_sort(int *arr, int n)
{
	// Your code here
}

void merge_sel_sort(int *arr, int n)
{
    // Your code here
}


