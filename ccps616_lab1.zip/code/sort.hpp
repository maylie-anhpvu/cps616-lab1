/*
    *** DO NOT MODIFY THIS FILE ***
    
    Functions in sort.cpp must match these prototypes.
    This is how they will be called in lab1.cpp
    However - you may use as many helper functions as
    you want in sort.cpp.
*/

void selection_sort(int *arr, int n);
void merge_sort(int *arr, int n);
void merge_sel_sort(int *arr, int n);